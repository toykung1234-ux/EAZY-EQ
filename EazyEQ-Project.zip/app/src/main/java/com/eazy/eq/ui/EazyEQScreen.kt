package com.eazy.eq.ui

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.eazy.eq.ui.components.*
import com.eazy.eq.ui.theme.StudioBackground

@Composable
fun EazyEQScreen() {
    var bassBoost by remember { mutableStateOf(50f) }
    var virtualizer by remember { mutableStateOf(30f) }
    var reverb by remember { mutableStateOf(20f) }
    val eqBands = remember { mutableStateListOf(0f, 2f, 4f, 1f, -2f, 0f, 3f, 5f, 2f, 0f) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(StudioBackground)
            .padding(16.dp)
            .verticalScroll(rememberScrollState())
    ) {
        Text(
            text = "EAZY EQ",
            fontSize = 28.sp,
            fontWeight = FontWeight.Bold,
            color = Color.White,
            modifier = Modifier.padding(bottom = 16.dp)
        )

        SpectrumVisualizer()
        Spacer(modifier = Modifier.height(16.dp))

        VUMeter(levelLeft = 0.7f, levelRight = 0.65f)
        Spacer(modifier = Modifier.height(24.dp))

        Text(text = "10-Band Equalizer", color = Color.White, fontWeight = FontWeight.SemiBold)
        EQCurveCanvas(bandsDb = eqBands)
        Spacer(modifier = Modifier.height(24.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            EffectDialControl("Bass Boost", bassBoost, { bassBoost = it }, Modifier.weight(1f))
            EffectDialControl("Virtualizer", virtualizer, { virtualizer = it }, Modifier.weight(1f))
            EffectDialControl("Reverb", reverb, { reverb = it }, Modifier.weight(1f))
        }
    }
}