package com.eazy.eq.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Path
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.unit.dp
import com.eazy.eq.ui.theme.NeonCyan

@Composable
fun EQCurveCanvas(
    bandsDb: List<Float>,
    modifier: Modifier = Modifier.fillMaxWidth().height(180.dp)
) {
    Canvas(modifier = modifier) {
        if (bandsDb.isEmpty()) return@Canvas
        val width = size.width
        val height = size.height
        val centerY = height / 2f
        val stepX = width / (bandsDb.size - 1).coerceAtLeast(1)

        val path = Path()
        bandsDb.forEachIndexed { index, db ->
            val x = index * stepX
            val y = centerY - (db / 12f * (centerY * 0.8f))
            if (index == 0) path.moveTo(x, y) else path.lineTo(x, y)
        }

        drawPath(
            path = path,
            color = NeonCyan,
            style = Stroke(width = 4.dp.toPx())
        )
    }
}