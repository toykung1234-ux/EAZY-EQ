package com.eazy.eq.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.unit.dp
import com.eazy.eq.ui.theme.VUGreen
import com.eazy.eq.ui.theme.VURed
import com.eazy.eq.ui.theme.VUYellow

@Composable
fun VUMeter(
    levelLeft: Float,
    levelRight: Float,
    modifier: Modifier = Modifier.fillMaxWidth().height(30.dp)
) {
    Canvas(modifier = modifier) {
        val segments = 16
        val segmentWidth = size.width / segments
        val h = size.height / 2.5f

        for (i in 0 until segments) {
            val color = when {
                i > 13 -> VURed
                i > 10 -> VUYellow
                else -> VUGreen
            }
            val alpha = if (i.toFloat() / segments <= levelLeft) 1f else 0.2f
            drawRect(
                color = color.copy(alpha = alpha),
                topLeft = Offset(i * segmentWidth, 0f),
                size = Size(segmentWidth * 0.8f, h)
            )
            val alphaR = if (i.toFloat() / segments <= levelRight) 1f else 0.2f
            drawRect(
                color = color.copy(alpha = alphaR),
                topLeft = Offset(i * segmentWidth, h * 1.2f),
                size = Size(segmentWidth * 0.8f, h)
            )
        }
    }
}