package com.eazy.eq

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import com.eazy.eq.ui.EazyEQScreen
import com.eazy.eq.ui.theme.EazyEQTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent {
            EazyEQTheme {
                EazyEQScreen()
            }
        }
    }
}