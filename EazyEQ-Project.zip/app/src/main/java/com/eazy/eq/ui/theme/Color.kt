package com.eazy.eq.ui.theme

import androidx.compose.ui.graphics.Color

val StudioBackground = Color(0xFF0F111A)
val StudioCardBackground = Color(0xFF181B26)
val NeonCyan = Color(0xFF00F2FE)
val NeonAmber = Color(0xFFFFB300)
val NeonPurple = Color(0xFF9D4EDD)
val VUGreen = Color(0xFF00E676)
val VUYellow = Color(0xFFFFEA00)
val VURed = Color(0xFFFF1744)