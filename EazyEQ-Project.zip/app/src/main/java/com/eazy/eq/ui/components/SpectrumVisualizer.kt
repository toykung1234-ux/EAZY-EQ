package com.eazy.eq.ui.components

import androidx.compose.foundation.Canvas
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Size
import androidx.compose.ui.unit.dp
import com.eazy.eq.ui.theme.NeonPurple

@Composable
fun SpectrumVisualizer(
    modifier: Modifier = Modifier.fillMaxWidth().height(120.dp)
) {
    Canvas(modifier = modifier) {
        val bars = 32
        val barWidth = size.width / (bars * 1.5f)
        for (i in 0 until bars) {
            val barHeight = (size.height * (0.2f + (i % 5) * 0.15f))
            drawRect(
                color = NeonPurple,
                topLeft = Offset(x = i * barWidth * 1.5f, y = size.height - barHeight),
                size = Size(width = barWidth, height = barHeight)
            )
        }
    }
}